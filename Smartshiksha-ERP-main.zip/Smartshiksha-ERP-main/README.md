# Smartshiksha-ERP
An online ERP system for managing students, teachers, and admin operations.
